package com.example.vehicleInventory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public interface VehicleConstants {

	
	
	List<String> validVehicleTypes=new ArrayList<>(Arrays.asList("Car","Truck","AirPlane","Amphibian","Boat"));
}
