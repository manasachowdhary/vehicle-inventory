package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Service;

import com.example.bean.Vehicle;
import com.example.bean.VehicleRequest;

@Service
public class VehicleService implements IVehicleService{


	@Autowired
	private JdbcTemplate jtm;

	@Override
	public List<Vehicle> findAll() {

		String sql = "SELECT * FROM VEHICLE";

		List<Vehicle> vehicle = jtm.query(sql, new BeanPropertyRowMapper(Vehicle.class));

		return vehicle;
	}

	@Override
	public Vehicle findById(Long id) {

		String sql = "SELECT * FROM VEHICLE WHERE ID=?";

		Vehicle Vehicle = (Vehicle) jtm.queryForObject(sql, new Object[]{id},
				new BeanPropertyRowMapper(Vehicle.class));

		return Vehicle;
	}

	@Override
	public int addVehicle(VehicleRequest request) {
		

		 int id= jtm.update("insert into VEHICLE (VEHICLENAME,VEHICLETYPE) " + "values(?,?)",
				new Object[] { request.getVehicleName(), request.getVehicleType() });
		
		
		return id;
		
	}

	@Override
	public int createVehicle(VehicleRequest request) throws Exception {
		
			return jtm.update("insert into VEHICLE (VEHICLENAME,VEHICLETYPE) " + "values(?,?)",
					new Object[] { request.getVehicleName(), request.getVehicleType() });
			
			
	}

	@Override
	public int deleteVehicle(Long id) {
		// TODO Auto-generated method stub
		return jtm.update("delete from VEHICLE where ID=?", new Object[] { id });

	}

	@Override
	public int updateVehicle(VehicleRequest request, Long id) {
		return jtm.update("update VEHICLE SET VEHICLENAME=?,VEHICLETYPE=? WHERE ID=? " ,
					new Object[] { request.getVehicleName(), request.getVehicleType(),id });
			
	}

}
