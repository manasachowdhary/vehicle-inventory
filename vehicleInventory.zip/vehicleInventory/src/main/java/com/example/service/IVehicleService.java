package com.example.service;

import java.util.List;

import com.example.bean.Vehicle;
import com.example.bean.VehicleRequest;

public interface IVehicleService {

    public List<Vehicle> findAll();
    public Vehicle findById(Long id);
	public int addVehicle(VehicleRequest request);
	public int createVehicle(VehicleRequest request) throws Exception;
	public int deleteVehicle(Long id);
	public int updateVehicle(VehicleRequest request, Long id);

}
