package com.example.cotroller;

import java.util.List;

import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.bean.Vehicle;
import com.example.bean.VehicleRequest;
import com.example.bean.VehicleResponse;
import com.example.service.IVehicleService;
import com.example.vehicleInventory.VehicleConstants;

@RestController
public class VehicleController {


	@Autowired
	private IVehicleService VehicleService;
	
	
	
	@POST
	@RequestMapping(value="/vehicle")
	public ResponseEntity<?> createVehicle(@RequestBody VehicleRequest request) {
		VehicleResponse response = new VehicleResponse();

		try {
			if (null != request && !StringUtils.isEmpty(request.getVehicleName())
					&& !StringUtils.isEmpty(request.getVehicleType())
					&& VehicleConstants.validVehicleTypes.contains(request.getVehicleType())) {
				return new ResponseEntity<String>("Vehicle Details Persisted", HttpStatus.OK);

			} else {
				return new ResponseEntity<String>("Mandatory params missing", HttpStatus.BAD_REQUEST);
			}

		} catch (Exception e) {
			return new ResponseEntity<String>("Exception persisting data", HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@RequestMapping(value="/vehicle/{id}",method=RequestMethod.PUT)
	@Produces(MediaType.APPLICATION_JSON)
	public ResponseEntity<?> updateVehicle(@RequestBody VehicleRequest request, @PathVariable Long id) {

		try {
			if (null != request && !StringUtils.isEmpty(request.getVehicleName())
					&& !StringUtils.isEmpty(request.getVehicleType())
					&& VehicleConstants.validVehicleTypes.contains(request.getVehicleType())
					&& !StringUtils.isEmpty(id)) {
				VehicleResponse response = new VehicleResponse();
				return new ResponseEntity<String>("Vehicle Details updated", HttpStatus.OK);

			} else {
				return new ResponseEntity<String>("Mandatory params missing", HttpStatus.BAD_REQUEST);
			}

		} catch (Exception e) {
			return new ResponseEntity<String>("Exception persisting data", HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	
	
	
	@RequestMapping(value="/vehicle/{id}",method=RequestMethod.DELETE)
	@Produces(MediaType.APPLICATION_JSON)
	public ResponseEntity<?> addVehicles(@PathVariable Long id) {

		try{
			if(!StringUtils.isEmpty(id)){
				return new ResponseEntity<String>("Vehicle Details deleted for requested Id", HttpStatus.OK);
			}else{
				return new ResponseEntity<String>("Mandatory params missing", HttpStatus.BAD_REQUEST);
			}

		}catch(Exception e){			
			return new ResponseEntity<String>("Exception persisting data", HttpStatus.INTERNAL_SERVER_ERROR);
		}


	}
	
	@RequestMapping(value = "/vehicle/{Id}", method = RequestMethod.GET)
	@ResponseBody
	public Vehicle findVehicle(@PathVariable Long Id) {

		return VehicleService.findById(Id);
	}
	
	@RequestMapping(value="/vehicles", method = RequestMethod.GET)
	public List<Vehicle> findVehicles() {

		return VehicleService.findAll();
	}




}
