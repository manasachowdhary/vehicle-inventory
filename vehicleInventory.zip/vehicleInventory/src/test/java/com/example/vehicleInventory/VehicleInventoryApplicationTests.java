package com.example.vehicleInventory;

//@RunWith(SpringRunner.class)
//@SpringBootTest
public class VehicleInventoryApplicationTests {

	//@Test
	public void contextLoads() {
	}

}
